# Entrega — projeto iOS 3105

Este ZIP contém o checkout completo atual do repositório `bts2019amo-ctrl/3105-public-build-20260918-copy`, incluindo as alterações locais nas configurações remotas, telas e workflow de CI. O histórico `.git`, credenciais locais e artefatos de build não estão incluídos.

## Estado

As alterações ainda não foram enviadas ao GitHub. O workflow foi ajustado para bloquear uma nova IPA enquanto o target continuar referenciando os grupos `exploit` e `kexploit` ou controles External/Ghost/stealth proibidos. Portanto, este ZIP é um checkout de trabalho, não uma IPA pronta para distribuição.

Uma credencial global embutida na IPA não é secreta; a entrega remota de senhas de pacotes precisa de autorização por instalação revogável e validada pelo servidor antes da liberação.

## Update 2026-11-11 — worse_query + pathleak

Integrado o successor do bad_query (forcequitOS/worse_query):

- `exploit/worse_query.m` + `worse_query.h` — sandbox extension via symlink + container_query class 7 (iOS 26–27)
- `exploit/pathleak.m` + `pathleak.h` — enumeração de paths por brute-force de inode + fsgetpath (mais limpo que bad_query_list)
- Bridging header atualizado
- project.pbxproj: files adicionados no group exploit + Sources
- ContainerStore.enumerateDirectories agora tenta pathleak primeiro em iOS ≥ 26, fallback pro bad_query_list

**Nota:** worse_query exige App Group configurado no target (entitlements + provisioning). Sem o group identifier, continue usando bad_query (já presente). pathleak funciona independente de group.
